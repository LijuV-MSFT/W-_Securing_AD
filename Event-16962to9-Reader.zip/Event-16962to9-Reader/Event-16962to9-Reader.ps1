﻿# -----------------------------------------------------------------------------
# This script scans Event Log (.evtx) files in a directory for Restrict Remote 
# SAM events and generates CSV files and an Excel workbook (.xlsx) for further 
# analysis.
#
# Last updated: 10/19/2016 (initial draft)
#
# Based on the script: "Event 1664 Reader v1.04" by Ming Chen
#                      https://support.microsoft.com/en-us/kb/3060643 
# -----------------------------------------------------------------------------


# -----------------------------------------------------------------------------
# Helper Functions
# -----------------------------------------------------------------------------

Function ConvertClient ($client) 
<# 
 # Description:
 #      This function extracts a client's IP address or Port number
 #
 # Parameters:
 #      $client[0] = string 
 #      $client[1] = "IP" or "Port", depending on what you want to extract
 #
 # Return Value:
 #      String value containing either the client's IP address, the client's port, or "Unkown"
 #>
{
    $ret_str = "Unknown"
    
    [regex]$regex_IPV6   = '(?<IP>\[[A-Fa-f0-9:%]{1,}\])\:(?<Port>([0-9]+))|(?<IP>\[[A-Fa-f0-9:%]{1,}\])'
    [regex]$regex_IPV4   = '((?<IP>(\d{1,3}\.){3}\d{1,3})\:(?<Port>[0-9]+))|(?<IP>(\d{1,3}\.){3}\d{1,3})' 
    [regex]$known_client = '(?<IP>([G-Z])\w+)' 
        
    switch -regex ($client[0]) 
    { 
        $regex_IPV6 { 
            $ret_str = $matches.($client[1])
            If ($client[1] -eq "IP") 
            { 
                $ret_str = $ret_str.Substring(1, $ret_str.Length-2)
            } 
        }
        $regex_IPV4 { 
            $ret_str = $matches.($client[1]) 
        } 
        $known_client { 
            $ret_str = $matches.($client[1]) 
        } 
    }
    $ret_str 
} 


Function SetPivotField ($pivot_field_setting)
<# 
 # Description:
 #      This function sets a Pivot Table's fields.
 #
 # Parameters:
 #      $pivot_field_setting[0]       = reference to pivot table of interest
 #      $pivot_field_setting[1] - [7] = attribute settings (see inline comments for specifics)
 #
 # Return Value:
 #      none
 #>
{ 
    # Set pivot field attributes per MSDN
    If ($pivot_field_setting[1] -ne $null) { $pivot_field_setting[0].Orientation  = $pivot_field_setting[1]} # 1 Orientation { $xlRowField | $xlDataField }, in Xl Pivot Field Orientation
    If ($pivot_field_setting[2] -ne $null) { $pivot_field_setting[0].NumberFormat = $pivot_field_setting[2]} # 2 NumberFormat { $NumberF | $PercentF }
    If ($pivot_field_setting[3] -ne $null) { $pivot_field_setting[0].Function     = $pivot_field_setting[3]} # 3 Function { $xlAverage | $xlSum | $xlCount }, in XlConsolidationFunction
    If ($pivot_field_setting[4] -ne $null) { $pivot_field_setting[0].Calculation  = $pivot_field_setting[4]} # 4 Calculation { $xlPercentOfTotal | $xlPercentRunningTotal }, in XlPivotFieldCalculation
    If ($pivot_field_setting[5] -ne $null) { $pivot_field_setting[0].BaseField    = $pivot_field_setting[5]} # 5 BaseField  <String>
    If ($pivot_field_setting[6] -ne $null) { $pivot_field_setting[0].Name         = $pivot_field_setting[6]} # 6 Name <String>
    If ($pivot_field_setting[7] -ne $null) { $pivot_field_setting[0].Position     = $pivot_field_setting[7]} # 7 Position
}


Function SetPivotTableFormat($PivotTable)
<# 
 # Description:
 #      This function formats a Pivot Table.
 #
 # Parameters:
 #      $pivot_field_setting[0]       = reference to pivot table of interest
 #      $pivot_field_setting[1] - [7] = attribute settings (see inline comments for specifics)
 #
 # Return Value:
 #      none
 #>
{ 
    # Set pivotTable cosmetics and sheet name
    $PT = $PivotTable[0].PivotTables($PivotTable[1])
    $PT.HasAutoFormat = $TRUE #2.turn of AutoColumnWidth
    
    For ($i=2; $i -lt 9; $i++)
    { 
        #3. SetColumnWidth for Sheet($PivotTable[0]),PivotTable($PivotTable[1]),Column($PivotTable[2-8])
        If ($PivotTable[$i] -ne $null) 
        { 
            $PivotTable[0].Columns.Item(($i-1)).ColumnWidth = $PivotTable[$i]
        }
    }
    $PivotTable[0].Application.ActiveWindow.SplitRow = 3
    $PivotTable[0].Application.ActiveWindow.SplitColumn = 2
    $PivotTable[0].Application.ActiveWindow.FreezePanes = $true #1.Freeze R1C1
    
    $PivotTable[0].Cells.Item(1,1) = "SAM Server filter"
    
    $PivotTable[0].Cells.Item(3,1) = $PivotTable[9] #4 set TXT at R3C1 with PivotTableName$PivotTable[9]
    
    $PivotTable[0].Name = $PivotTable[10] #5 Set Sheet Name to $PivotTable[10]
    
    $RC = ($PivotTable[0].UsedRange.Cells).Rows.Count-1
    
    If ($PivotTable[11] -ne $null)
    { 
        # $PivotTable[11] Set ColorScale
        $olorScaleRange='$'+$PivotTable[11]+'$4:$'+$PivotTable[11]+'$'+$RC

        [void]$PivotTable[0].Range($olorScaleRange).FormatConditions.AddColorScale(3) #$PivotTable[11]=ColorScale
        
        $PivotTable[0].Range($olorScaleRange).FormatConditions.Item(1).ColorScaleCriteria.Item(1).Type = 1 #xlConditionValueLowestValue
        $PivotTable[0].Range($olorScaleRange).FormatConditions.Item(1).ColorScaleCriteria.Item(1).FormatColor.Color = 8109667
        $PivotTable[0].Range($olorScaleRange).FormatConditions.Item(1).ColorScaleCriteria.Item(2).FormatColor.Color = 8711167
        $PivotTable[0].Range($olorScaleRange).FormatConditions.Item(1).ColorScaleCriteria.Item(3).Type = 2 #xlConditionValueHighestValue
        $PivotTable[0].Range($olorScaleRange).FormatConditions.Item(1).ColorScaleCriteria.Item(3).FormatColor.Color = 7039480
    }
}


Function SortPivotFields ($PF)
<# 
 # Description:
 #      This function sorts the pivot fields.
 #
 # Parameters:
 #      $PF[0]   = reference to pivot table of interest
 #      $PF[...] = column of header field to be sorted
 #
 # Return Value:
 #      none
 #>
{ 
    # Sort on $PF and collapse later pivot fields
    For ($i=2; $i -lt 5; $i++) 
    { 
        # Collapse later pivot fields
        If ($PF[$i] -ne $null) 
        { 
            $PF[$i].ShowDetail = $false 
        }
    }
    $PF[0].Cells(4,2).Select() | Out-Null
    $Excel.CommandBars.ExecuteMso("SortDescendingExcel")
}


Function SetPivotTableHeaderColor ($sheet)
<# 
 # Description:
 #      This function sets the colors for a sheet's Pivot Table header fields.
 #
 # Parameters:
 #      $sheet[0]   = reference to sheet of interest
 #      $sheet[...] = column of header field to be colorized
 #
 # Return Value:
 #      none
 #>
{
    # Set PiviotTable Header Color for easier reading
    $sheet[0].Range("A4:"+[char]($sheet[0].UsedRange.Cells.Columns.Count+64)+[string](($sheet[0].UsedRange.Cells).Rows.Count-1)).Interior.Color = 16056319 #Set Level0 color
    For ($i=1; $i -lt 5; $i++) 
    { 
        # Set header(s) color
        If ($sheet[$i] -ne $null) 
        { 
            $sheet[0].Range(($sheet[$i]+"3")).Interior.Colorindex = 37 
        }
    }
}


Function AddEvtMember ($evt_info)
<# 
 # Description:
 #      This function adds a data field to an Event object.
 #
 # Parameters:
 #      $evt_info[0] = reference to an event object
 #      $evt_info[1] = name of property to add
 #      $evt_info[2] = value of property to add
 #
 # Return Value:
 #      none
 #>
{
    $evt_info[0] | Add-Member -MemberType NoteProperty -Name $evt_info[1] -Force -Value $evt_info[2]
}

Function WriteHost ($str)
{
    Write-Host "`n    $str"
}

# -----------------------------------------------------------------------------
# Main script body
# -----------------------------------------------------------------------------

#
# (Step 0) Determine path to .evtx files
#
cls
Write-Host "`n* Running script to identify Restrict-Remote-SAM events`n" -ForegroundColor Yellow

$path_to_script = Split-Path ( (Get-Variable MyInvocation -Scope 0).Value ).MyCommand.Path
$path_to_evtx   = Read-Host "`nEnter path to Event Log (.evtx) files. Be sure to remove any trailing whitespace. For example: `"c:\Case-Data-Folder`"`nOr press [Enter] if the .evtx is located in the same directory as the script`n`n"

# If no path is supplied, use the script's path
If ($path_to_evtx -eq "")
{
    WriteHost ("Scanning for Event Log files in path: $path_to_script")
    $path_to_evtx = $path_to_script
}


#
# (Step 1) For each Event Log file, extract the relevant events and save them to separate CSV files
#
Get-ChildItem -Path $path_to_evtx | Where-Object { $_.extension -eq '.evtx' } | ForEach-Object ( $_ ) {

    WriteHost ( "Parsing file: $_" )
    
    $events_all_ids = 16962..16969
    $events_all = Get-WinEvent -FilterHashtable @{ Path = $path_to_evtx + '\' + $_.Name; ProviderName = "Microsoft-Windows-Directory-Services-SAM"; ID = $events_all_ids } -ErrorAction SilentlyContinue
    If ($events_all -ne $null)
    {
        WriteHost ("    Events for Restrict-Remote-SAM were found..." )

        $out_file_all = $path_to_evtx + '\1696X-all-' + $_.BaseName + '.csv'
        $new_file = $TRUE

        $evt = New-Object System.Object
        ForEach ($event in $events_all)
        {
            # Fields that all events have in common
            AddEvtMember($evt, "Event ID", $event.Id)
            AddEvtMember($evt, "Server", $event.MachineName)
            AddEvtMember($evt, "Time Generated", $event.TimeCreated)

            # Fields that may differ between events
            switch ($event.Id)
            {
                16962 {
                    If ($event.Properties[0].Value -eq "") {
                        $SDDL = "empty"
                    }
                    Else {
                        $SDDL = $event.Properties[0].Value
                    }

                    AddEvtMember($evt, "Default SD String", $SDDL)
                    AddEvtMember($evt, "Registry SD String", "")
                    AddEvtMember($evt, "Malformed SD String", "")
                    AddEvtMember($evt, "Client SID", "")
                    AddEvtMember($evt, "Client Network Address", "")
                    AddEvtMember($evt, "Throttle Window (sec)" , "")
                    AddEvtMember($evt, "Suppressed Message Count", "")
                    AddEvtMember($evt, "Name", "DEFAULT SD")
                }

                16963 {
                    AddEvtMember($evt, "Default SD String", "")
                    AddEvtMember($evt, "Registry SD String", $event.Properties[0].Value)
                    AddEvtMember($evt, "Malformed SD String", "")
                    AddEvtMember($evt, "Client SID", "")
                    AddEvtMember($evt, "Client Network Address", "")
                    AddEvtMember($evt, "Throttle Window (sec)" , "")
                    AddEvtMember($evt, "Suppressed Message Count", "")
                    AddEvtMember($evt, "Name", "REGISTRY SD")
                }

                16964 {
                    AddEvtMember($evt, "Default SD String", $event.Properties[1].Value)
                    AddEvtMember($evt, "Registry SD String", "")
                    AddEvtMember($evt, "Malformed SD String", $event.Properties[0].Value)
                    AddEvtMember($evt, "Client SID", "")
                    AddEvtMember($evt, "Client Network Address", "")
                    AddEvtMember($evt, "Throttle Window (sec)" , "")
                    AddEvtMember($evt, "Suppressed Message Count","")
                    AddEvtMember($evt, "Name", "SD MALFORMED")
                }

                16965 {
                    AddEvtMember($evt, "Default SD String", "")
                    AddEvtMember($evt, "Registry SD String", "")
                    AddEvtMember($evt, "Malformed SD String", "")
                    AddEvtMember($evt, "Client SID", $event.Properties[0].Value)
                    AddEvtMember($evt, "Client Network Address", (ConvertClient($event.Properties[1].Value, 'IP')))
                    AddEvtMember($evt, "Throttle Window (sec)", "")
                    AddEvtMember($evt, "Suppressed Message Count", "")
                    AddEvtMember($evt, "Name", "ACCESS DENIED")
                }

                16966 { # does not have any data fields
                    AddEvtMember($evt, "Default SD String", "")
                    AddEvtMember($evt, "Registry SD String", "")
                    AddEvtMember($evt, "Malformed SD String", "")
                    AddEvtMember($evt, "Client SID", "")
                    AddEvtMember($evt, "Client Network Address", "")
                    AddEvtMember($evt, "Throttle Window (sec)", "")
                    AddEvtMember($evt, "Suppressed Message Count", "")
                    AddEvtMember($evt, "Name", "AUDIT MODE ENABLED")
                }

                16967 { # does not have any data fields
                    AddEvtMember($evt, "Default SD String", "")
                    AddEvtMember($evt, "Registry SD String", "")
                    AddEvtMember($evt, "Malformed SD String", "")
                    AddEvtMember($evt, "Client SID", "")
                    AddEvtMember($evt, "Client Network Address", "")
                    AddEvtMember($evt, "Throttle Window (sec)" , "")
                    AddEvtMember($evt, "Suppressed Message Count", "")
                    AddEvtMember($evt, "Name", "AUDIT MODE DISABLED")
                }

                16968 {
                    AddEvtMember($evt, "Default SD String", "")
                    AddEvtMember($evt, "Registry SD String", "")
                    AddEvtMember($evt, "Malformed SD String", "")
                    AddEvtMember($evt, "Client SID", $event.Properties[0].Value)
                    AddEvtMember($evt, "Client Network Address", (ConvertClient($event.Properties[1].Value, 'IP')))
                    AddEvtMember($evt, "Throttle Window (sec)" , "")
                    AddEvtMember($evt, "Suppressed Message Count", "")
                    AddEvtMember($evt, "Name", "AUDIT MODE ENABLED")
                }

                16969 {
                    AddEvtMember($evt, "Default SD String", "")
                    AddEvtMember($evt, "Registry SD String", "")
                    AddEvtMember($evt, "Malformed SD String", "")
                    AddEvtMember($evt, "Client SID", "")
                    AddEvtMember($evt, "Client Network Address", "")
                    AddEvtMember($evt, "Throttle Window (sec)", $event.Properties[0].Value)
                    AddEvtMember($evt, "Suppressed Message Count", $event.Properties[1].Value)
                    AddEvtMember($evt, "Name", "EVENT THROTTLING")
                }
            } # end switch

            If ($new_file)
            {
                # Generate header labels for the new file
                ConvertTo-Csv $evt -NoTypeInformation | Out-File $out_file_all
                $new_file = $FALSE
            }
            Else
            { 
                # Just append the event data
                $temp = (ConvertTo-Csv $evt -NoTypeInformation)
                Write-Output $temp[1] | Out-File $out_file_all -Append
            }

        } # end for each

        Remove-Variable evt
    }
    Else 
    {
        WriteHost ("    No events for Restrict-Remote-SAM were found..." )
    }

    $events_access_denied_ids = 16965
    $events_access_denied = Get-WinEvent -FilterHashtable @{ Path = $path_to_evtx + '\' + $_.Name; ProviderName = "Microsoft-Windows-Directory-Services-SAM"; ID = $events_access_denied_ids } -ErrorAction SilentlyContinue
    If ($events_access_denied -ne $null)
    {
        $out_file_access_denied = $path_to_evtx + '\1696X-access_denied-' + $_.BaseName + '.csv'        
        $new_file = $TRUE

        $evt = New-Object System.Object
        ForEach ($event in $events_access_denied)
        {
            AddEvtMember($evt, "Event ID", $event.Id)
            AddEvtMember($evt, "Server", $event.MachineName)
            AddEvtMember($evt, "Time Generated", $event.TimeCreated)

            AddEvtMember($evt, "Client SID", $event.Properties[0].Value)
            AddEvtMember($evt, "Client Network Address", (ConvertClient($event.Properties[1].Value, 'IP')))
        
            If ($new_file)
            {
                # Generate header labels for the new file
                ConvertTo-Csv $evt -NoTypeInformation | Out-File $out_file_access_denied
                $new_file = $FALSE
            }
            Else
            { 
                # Just append the event data
                $temp = (ConvertTo-Csv $evt -NoTypeInformation)
                Write-Output $temp[1] | Out-File $out_file_access_denied -Append
            }
        }

        Remove-Variable evt
    }

    $events_audit_ids = 16966..16968
    $events_audit = Get-WinEvent -FilterHashtable @{ Path = $path_to_evtx + '\' + $_.Name; ProviderName = "Microsoft-Windows-Directory-Services-SAM"; ID = $events_audit_ids } -ErrorAction SilentlyContinue
    If ($events_audit -ne $null)
    {
        $out_file_audit = $path_to_evtx + '\1696X-audit-' + $_.BaseName + '.csv'        
        $new_file = $TRUE

        $evt = New-Object System.Object
        ForEach ($event in $events_audit)
        {
            AddEvtMember($evt, "Event ID", $event.Id)
            AddEvtMember($evt, "Server", $event.MachineName)
            AddEvtMember($evt, "Time Generated", $event.TimeCreated)
            $enabled = "No"
            If ($event.Id -ne 16967) 
            {
                $enabled = "Yes"
            }
            AddEvtMember($evt, "Audit Mode Enabled", $enabled)
        
            If ($new_file)
            {
                # Generate header labels for the new file
                ConvertTo-Csv $evt -NoTypeInformation | Out-File $out_file_audit
                $new_file = $FALSE
            }
            Else
            { 
                # Just append the event data
                $temp = (ConvertTo-Csv $evt -NoTypeInformation)
                Write-Output $temp[1] | Out-File $out_file_audit -Append
            }
        }

        Remove-Variable evt
    }

    $events_sd_ids = 16962..16964
    $events_sd = Get-WinEvent -FilterHashtable @{ Path = $path_to_evtx + '\' + $_.Name; ProviderName = "Microsoft-Windows-Directory-Services-SAM"; ID = $events_sd_ids } -ErrorAction SilentlyContinue
    If ($events_sd -ne $null)
    {
        $out_file_sd = $path_to_evtx + '\1696X-sd-' + $_.BaseName + '.csv'        
        $new_file = $TRUE

        $evt = New-Object System.Object
        ForEach ($event in $events_sd)
        {
            AddEvtMember($evt, "Event ID", $event.Id)
            AddEvtMember($evt, "Server", $event.MachineName)
            AddEvtMember($evt, "Time Generated", $event.TimeCreated)

            $cur_sd = $event.Properties[0].Value
            If ($event.Id -eq 16964)
            {
                $cur_sd = $event.Properties[1].Value
            }
            If ($cur_sd -eq "") 
            {
                $cur_sd = "none"
            } 
            AddEvtMember($evt, "Current SD in Use", $cur_sd)
        
            If ($new_file)
            {
                # Generate header labels for the new file
                ConvertTo-Csv $evt -NoTypeInformation | Out-File $out_file_sd
                $new_file = $FALSE
            }
            Else
            { 
                # Just append the event data
                $temp = (ConvertTo-Csv $evt -NoTypeInformation)
                Write-Output $temp[1] | Out-File $out_file_sd -Append
            }
        }

        Remove-Variable evt
    }
}


#
# (Step 2) Generate an Excel workbook from the CSV files
#
$csv_files_all = Get-ChildItem -Path $path_to_evtx | Where-Object { $_.Name -clike "1696X-all-*.csv" }
If ($csv_files_all -ne $null) 
{
    WriteHost ("Generating an Excel workbook...")

    $excel = New-Object -ComObject Excel.Application
    $excel.Visible = $FALSE
    $workbook = $excel.Workbooks.Add()

    # Sheet 1: raw data for all events
    $sheet1 = $workbook.Worksheets.Item(1)
    
    $cur_row = 1
    ForEach ($file in $csv_files_all)
    {
        # current CSV line
        $connector = $sheet1.QueryTables.add( ("TEXT;" + $path_to_evtx + '\' + $file), $sheet1.Range(('A' + ($cur_row))) )

        $sheet1.QueryTables.Item($connector.Name).TextFileCommaDelimiter = $TRUE
        $sheet1.QueryTables.Item($connector.Name).TextFileParseType = 1

        [void]$sheet1.QueryTables.Item($connector.Name).Refresh()

        If ($cur_row -ne 1) 
        {
            # Delete the headers for 2nd rows and beyond
            [void]$sheet1.Cells.Item($cur_row, 1).EntireRow.Delete()
        }

        $cur_row = $sheet1.UsedRange.EntireRow.Count + 1
    }
    $sheet1.Range("A1").Autofilter() | Out-Null
    $sheet1.Application.ActiveWindow.SplitRow = 1
    $sheet1.Application.ActiveWindow.FreezePanes = $TRUE

    # Sheet 2: raw data for access denied events
    $sheet2 = $workbook.Worksheets.Add()

    $csv_files_access_denied = Get-ChildItem -Path $path_to_evtx | Where-Object { $_.Name -clike "1696X-access_denied-*.csv" }
    If ($csv_files_access_denied -ne $null) 
    {
        # For each CSV file, get the raw data and import it into same query table
        $cur_row = 1
        ForEach ($file in $csv_files_access_denied)
        {
            # current CSV line
            $connector2 = $sheet2.QueryTables.add( ("TEXT;" + $path_to_evtx + '\' + $file), $sheet2.Range(('A' + ($cur_row))) )

            $sheet2.QueryTables.Item($connector2.Name).TextFileCommaDelimiter = $TRUE
            $sheet2.QueryTables.Item($connector2.Name).TextFileParseType = 1

            [void]$sheet2.QueryTables.Item($connector2.Name).Refresh()

            If ($cur_row -ne 1) 
            {
                # Delete the headers for 2nd rows and beyond
                [void]$sheet2.Cells.Item($cur_row, 1).EntireRow.Delete()
            }

            $cur_row = $sheet2.UsedRange.EntireRow.Count + 1
        }

        $sheet2.Range("A1").Autofilter() | Out-Null
        $sheet2.Application.ActiveWindow.SplitRow = 1
        $sheet2.Application.ActiveWindow.FreezePanes = $TRUE
    }
    Else
    {
        $sheet2.Range("A1").value = "No access denied events for Restrict-Remote-SAM were found"
    }

    # Sheet 3: raw data for audit events
    $sheet3 = $workbook.Worksheets.Add()

    $csv_files_audit = Get-ChildItem -Path $path_to_evtx | Where-Object { $_.Name -clike "1696X-audit-*.csv" }
    If ($csv_files_audit -ne $null) {
        # For each CSV file, get the raw data and import it into same query table
        $cur_row = 1
        ForEach ($file in $csv_files_audit)
        {
            # current CSV line
            $connector = $sheet3.QueryTables.add( ("TEXT;" + $path_to_evtx + '\' + $file), $sheet3.Range(('A' + ($cur_row))) )

            $sheet3.QueryTables.Item($connector.Name).TextFileCommaDelimiter = $TRUE
            $sheet3.QueryTables.Item($connector.Name).TextFileParseType = 1

            [void]$sheet3.QueryTables.Item($connector.Name).Refresh()

            If ($cur_row -ne 1) 
            {
                # Delete the headers for 2nd rows and beyond
                [void]$sheet3.Cells.Item($cur_row, 1).EntireRow.Delete()
            }

            $cur_row = $sheet3.UsedRange.EntireRow.Count + 1
        }

        $sheet3.Range("A1").Autofilter() | Out-Null
        $sheet3.Application.ActiveWindow.SplitRow = 1
        $sheet3.Application.ActiveWindow.FreezePanes = $TRUE
    }
    Else 
    {
        $sheet3.Range("A1").value = "No auditing events for Restrict-Remote-SAM were found"
    }

    # Sheet 4: Raw Data 4
    $sheet4 = $workbook.Worksheets.Add()

    $csv_files_sd = Get-ChildItem -Path $path_to_evtx | Where-Object { $_.Name -clike "1696X-sd-*.csv" }
    If ($csv_files_sd -ne $null) {
        # For each CSV file, get the raw data and import it into same query table
        $cur_row = 1
        ForEach ($file in $csv_files_sd)
        {
            # current CSV line
            $connector = $sheet4.QueryTables.add( ("TEXT;" + $path_to_evtx + '\' + $file), $sheet4.Range(('A' + ($cur_row))) )

            $sheet4.QueryTables.Item($connector.Name).TextFileCommaDelimiter = $TRUE
            $sheet4.QueryTables.Item($connector.Name).TextFileParseType = 1

            [void]$sheet4.QueryTables.Item($connector.Name).Refresh()

            If ($cur_row -ne 1) 
            {
                # Delete the headers for 2nd rows and beyond
                [void]$sheet4.Cells.Item($cur_row, 1).EntireRow.Delete()
            }

            $cur_row = $sheet4.UsedRange.EntireRow.Count + 1
        }

        $sheet4.Range("A1").Autofilter() | Out-Null
        $sheet4.Application.ActiveWindow.SplitRow = 1
        $sheet4.Application.ActiveWindow.FreezePanes = $TRUE
    }
    Else 
    {
        $sheet4.Range("A1").value = "No SDDL events for Restrict-Remote-SAM were found"
    }

    #
    # Formatting settings for pivot tables
    #
    $xl_src_type = 1                            # xlDatabase
    $xl_version = 5                             # Excel 2013
    $xl_row_field = 1                           # XlPivotFieldOrientation
    $xl_page_field = 3                          # XlPivotFieldOrientation
    $xl_data_field = 4                          # XlPivotFieldOrientation
    $xl_average = -4106                         # XlConsolidationFunction
    $xl_sum = -4157                             # XlConsolidationFunction
    $xl_count= -4112                            # XlConsolidationFunction
    $xl_percent_of_total = 8                    # XlPivotFieldCalculation
    $xl_percent_running_total = 13              # XlPivotFieldCalculation

    $NumberF = "###,###,###,###,###"
    $PercentF = "#0.00%"
    $DateGroupFlags=($false, $true, $true, $true, $false, $false, $false) #https://msdn.microsoft.com/en-us/library/office/ff839808.aspx

    #
    # Sheet 5: Pivot Table 1
    #
    $sheet5 = $workbook.Worksheets.Add()
    
    $pivot_table1 = $workbook.PivotCaches().Create($xl_src_type, "Sheet1!R1C1:R$($sheet1.UsedRange.Rows.count)C$($sheet1.UsedRange.Columns.count)", $xl_version)
    $pivot_table1.CreatePivotTable("Sheet5!R1C1") | Out-Null

    $PF00 = $sheet5.PivotTables("PivotTable1").PivotFields("Server")
    SetPivotField($PF00, $xl_page_field, $null, $null, $null, $null, $null)

    $PF0 = $sheet5.PivotTables("PivotTable1").PivotFields("Name")
    SetPivotField($PF0, $xl_row_field, $null, $null, $null, $null, $null)

    $PF1 = $sheet5.PivotTables("PivotTable1").PivotFields("Event ID")
    SetPivotField($PF1, $xl_row_field, $null, $null, $null, $null, $null)

    $PF = $sheet5.PivotTables("PivotTable1").PivotFields("Time Generated")
    SetPivotField($PF, $xl_row_field, $null, $null, $null, $null, $null)

    $Cells = $PF.DataRange.Item(3)
    $Cells.group($TRUE, $TRUE, 1, $DateGroupFlags) | Out-Null
    
    $PF = $sheet5.PivotTables("PivotTable1").PivotFields("Event ID")
    SetPivotField($PF, $xl_data_field, $NumberF, $xl_count, $null, $null, "# of Occurrences", 1)

    $PF = $sheet5.PivotTables("PivotTable1").PivotFields("Name")
    SetPivotField($PF, $xl_data_field, $PercentF, $null, $xl_percent_of_total, $null, "% Grand Total", 2)
    
    $PF = $sheet5.PivotTables("PivotTable1").PivotFields("Name")
    SetPivotField($PF, $xl_data_field, $PercentF, $null, $xl_percent_running_total, "Name", "% Running Total", 3)
    
    SetPivotTableFormat($sheet5, "PivotTable1", $null, $null, $null, $null, $null, $null, $null,"Event Types", "5.EventTypes","C","D")
    SortPivotFields($sheet5, $PF00, $PF0, $PF1)
    SetPivotTableHeaderColor($sheet5, "B")
    
    #
    # Sheet 6: Pivot Table 2
    #
    $sheet6 = $workbook.Worksheets.Add()
    If ($csv_files_access_denied -ne $null) 
    {
        $pivot_table2 = $workbook.PivotCaches().Create($xl_src_type, "Sheet2!R1C1:R$($sheet2.UsedRange.Rows.count)C$($sheet2.UsedRange.Columns.count)", $xl_version)
        $pivot_table2.CreatePivotTable("Sheet6!R1C1") | Out-Null

        $PF00 = $sheet6.PivotTables("PivotTable2").PivotFields("Server")
        SetPivotField($PF00, $xl_page_field, $null, $null, $null, $null, $null)

        $PF0 = $sheet6.PivotTables("PivotTable2").PivotFields("Client SID")
        SetPivotField($PF0, $xl_row_field, $null, $null, $null, $null, $null)

        $PF1 = $sheet6.PivotTables("PivotTable2").PivotFields("Client Network Address")
        SetPivotField($PF1, $xl_row_field, $null, $null, $null, $null, $null)

        $PF = $sheet6.PivotTables("PivotTable2").PivotFields("Time Generated")
        SetPivotField($PF, $xl_row_field, $null, $null, $null, $null, $null)

        $Cells = $PF.DataRange.Item(3)
        $Cells.group($TRUE, $TRUE, 1, $DateGroupFlags) | Out-Null
        
        $PF = $sheet6.PivotTables("PivotTable2").PivotFields("Event ID")
        SetPivotField($PF, $xl_data_field, $NumberF, $xl_count, $null, $null, "# of Occurrences", 1)

        $PF = $sheet6.PivotTables("PivotTable2").PivotFields("Client SID")
        SetPivotField($PF, $xl_data_field, $PercentF, $null, $xl_percent_of_total, $null, "% Grand Total",2)
        
        $PF = $sheet6.PivotTables("PivotTable2").PivotFields("Client SID")
        SetPivotField($PF, $xl_data_field, $PercentF, $null, $xl_percent_running_total, "Client SID", "% Running Total",3)

        SetPivotTableFormat($sheet6, "PivotTable2", $null, $null, $null, $null, $null, $null, $null,"Clients Denied Access", "6.AccessDenied","C","D")
        SortPivotFields($sheet6, $PF00, $PF0, $PF1)
        SetPivotTableHeaderColor($sheet6, "B")
    }
    Else {
        $sheet6.Range("A1").value = "No access denied events relating to Restrict-Remote-SAM were found"
    }

    #
    # All sheets are generated. Name & rearrange the sheets in reverse (expected order)
    #
    $sheet1.Name = "1.Evts-All"
    $sheet2.Name = "2.Evts-AccessDenied"
    $sheet3.Name = "3.Evts-Audit"
    $sheet4.Name = "4.Evts-SD"
    $sheet5.Name = "5.EventTypes"
    $sheet6.Name = "6.AccessDenied"

    $worksheet_names = New-Object System.Collections.ArrayList
    ForEach ($worksheet in $workbook.Worksheets)
    {
        $worksheet_names.Add($worksheet.Name) | Out-Null
    }

    $temp = $worksheet_names.Sort() | Out-Null

    For ($i = 0; $i -lt $worksheet_names.Count - 1; $i++)
    {
        $temp = $worksheet_names[$i]
        $prev = $workbook.Worksheets.Item($temp)
        $next = $workbook.Worksheets.Item($i + 1)
        $prev.Move($next)
    }

    $sheet1.Activate()

    #
    # Save the Excel file
    #
    $excel_file = Read-Host "`nEnter a file name to save the Excel Workbook"
    If ($excel_file)
    {
        WriteHost ("Saving file to $path_to_evtx\$excel_file.xlsx")
        $workbook.SaveAs($path_to_evtx + '\' + $excel_file)
    }

    #
    # Delete CSV files?
    #
    $delete_CSV = Read-Host "`nDelete generated 1696X-*.csv files? [Y]/[Enter] to delete, [N] to keep`n"
    If ($delete_CSV -ne 'N') # case-insensitive
    {
        $csv_files_all | ForEach-Object ( $_ ) {
            WriteHost ("Deleting file: $_")
            Remove-Item $path_to_evtx'\'$_
        }

        $csv_files_access_denied | ForEach-Object ( $_ ) {
            WriteHost ("Deleting file: $_")
            Remove-Item $path_to_evtx'\'$_
        }

        $csv_files_audit | ForEach-Object ( $_ ) {
            WriteHost ("Deleting file: $_")
            Remove-Item $path_to_evtx'\'$_
        }
        $csv_files_sd | ForEach-Object ( $_ ) {

            WriteHost ("Deleting file: $_")
            Remove-Item $path_to_evtx'\'$_
        }
    }

    $excel.Quit()
}
Else
{
    WriteHost ("No Excel Worksheet was created. No Restrict-Remote-SAM events found.")
}

Write-Host "`n* End of script`n" -ForegroundColor Yellow
