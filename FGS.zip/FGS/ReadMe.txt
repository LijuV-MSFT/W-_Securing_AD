Administrative Groups Collection and Report

The FGS script, written by Microsoft PFE Pierre Audonnet, documents members of selected administrative groups within the forest. It also provides detailed information about these privileged accounts as well as additional forest security information.

 For each built-in (and this could be extended with an input parameter) the script list all the members taking care of nested groups, loops and membership via the PrimaryID attribute.

 The script queries all the classes for their defaultSecurityDescriptor attributes and all the attributes for their searchFlags properties. The script does not require Active Direcotry Webservices. Unless the default permissions of the domain have been changed, a regular domain user can run the script.