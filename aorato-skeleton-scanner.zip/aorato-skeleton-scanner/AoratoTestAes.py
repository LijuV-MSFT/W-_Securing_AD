#!/usr/bin/python

# Supported Encryption Remote Detection Script

# Authors: Aorato's Research team
# ------
# Tal Be'ery 
# Contact : talbe at microsoft dot com
# https://twitter.com/TalBeerySec/

# Based on PyKek
# Author
# ------
# Sylvain Monne
# Contact : sylvain dot monne at solucom dot fr
# http://twitter.com/bidord



import sys, os
from random import getrandbits
from time import time, localtime, strftime
from subprocess import call
from binascii import unhexlify

if not os.path.isdir('..\\libs') and not os.path.isdir('.\\kek'):
    sys.stderr.write(' Libs directory is missing! make sure you have kek and pyasn1 lib before running this script.')
    sys.exit(1)

sys.path.append('..\\libs')

from kek.ccache import CCache, get_tgt_cred, kdc_rep2ccache
from kek.crypto import generate_subkey, ntlm_hash, RC4_HMAC, HMAC_MD5
from kek.krb5 import build_as_req, build_tgs_req, send_req, recv_rep, \
    decrypt_as_rep, decrypt_tgs_rep, decrypt_ticket_enc_part, iter_authorization_data, \
    AD_WIN2K_PAC, decode, KrbError, Ticket, KDC_ERR_ETYPE_NOSUPP, KDC_ERR_PREAUTH_REQUIRED, \
    AES256
from kek.pac import build_pac, pretty_print_pac
from kek.util import epoch2gt, gt2epoch
from struct import pack, unpack

def TestEnc(user_realm, user_name, kdc_a, etype):

    sys.stderr.write('  [+] Building AS-REQ for %s...' % kdc_a)
    sys.stderr.flush()
    nonce = getrandbits(31)
    current_time = time()
    as_req = build_as_req(user_realm, user_name, None, current_time, nonce, True, etype)
    sys.stderr.write(' Done!\n')
    
    sys.stderr.write('  [+] Sending AS-REQ to %s...' % kdc_a)
    sys.stderr.flush()
    sock = send_req(as_req, kdc_a)
    sys.stderr.write(' Done!\n')

    sys.stderr.write('  [+] Receiving KrbError from %s...' % kdc_a)
    sys.stderr.flush()
    data = recv_rep(sock)
    sys.stderr.write(' Done!\n')

    sys.stderr.write('  [+] Parsing KrbError from %s...' % kdc_a)
    sys.stderr.flush()
    err_enc = decode(data, asn1Spec=KrbError())[0]
    sys.stderr.write('  Error Code is %i!\n' % err_enc['error-code'])
    sys.stderr.flush()
     
    if (err_enc['error-code'] == KDC_ERR_ETYPE_NOSUPP):
         print "This encryption type is not supported\n"
         return False
    if (err_enc['error-code'] == KDC_ERR_PREAUTH_REQUIRED):
         print "This encryption type is supported\n"
         return True
     # if we got here some other error had occured (bad username etc.) 
    print "Some error had occured. please check input parameters validity.\n"
    return True

def offlinecheck():
    err_enc_buff = "000000d77e81d43081d1a003020105a10302011ea411180f32303135303131383133323832305aa505020308bbada603020119a91f1b1d4d4944444c45454153542e434f52502e4d4943524f534f46542e434f4daa323030a003020101a12930271b066b72627467741b1d4d4944444c45454153542e434f52502e4d4943524f534f46542e434f4dac51044f304d3016a10302010ba20f040d300b3009a003020117a10204003012a103020113a20b040930073005a0030201173009a103020102a20204003009a103020110a20204003009a10302010fa2020400"
    #err_enc_buff = "000000897e8186308183a003020105a10302011ea411180f32303135303131383133353334305aa505020308330ea60302010ea90e1b0c41545441434b44432e4f5247aa21301fa003020101a11830161b066b72627467741b0c41545441434b44432e4f5247ac25042330213009a103020102a20204003009a103020110a20204003009a10302010fa2020400"
    buff = unhexlify(err_enc_buff)
    datalen = unpack('>I', buff[:4])[0]
    print "len:" + str(datalen)
    if len(buff) >= 4 + datalen:
        buff = buff[4:(4 + datalen)]
    err_enc = decode(buff, asn1Spec=KrbError())[0]
    print err_enc['error-code']

if __name__ == '__main__':
    from getopt import getopt
 
    def usage_and_exit():
        print >> sys.stderr, 'USAGE:'
        print >> sys.stderr, '%s -u <userName>@<domainName> -d <domainControlerAddr>' % sys.argv[0]
        sys.exit(1)


    opts, args = getopt(sys.argv[1:], 'u:d:')
    opts = dict(opts)
    if not all(k in opts for k in ('-u', '-d')):
        usage_and_exit()

    user_name, user_realm = opts['-u'].split('@', 1)
    kdc_a = opts['-d']
    #print user_name + " " + user_realm
    #print "DC:" + kdc_a
   


    user_realm = user_realm.upper()
    

    etype=AES256

    TestEnc(user_realm, user_name, kdc_a,etype)
     
