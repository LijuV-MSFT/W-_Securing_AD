Aorato Skeleton Scanner
===================================
Remotely scans for the existence of the Skeleton Key Malware (http://www.secureworks.com/cyber-threat-intelligence/threats/skeleton-key-malware-analysis/)
The script works as follows:
* Verifies whether the Domain Functional Level (DFL) of current domain supports AES (>= 2008)
* Finds an AES supporting client account (msds-supportedencryptiontypes >= 8)
* Sends a Kerberos AS-REQ to all DCs with only AES E-type supported (Using python code based on PyKek https://github.com/bidord/pykek, see PyKek-original-README.md) 
* If AS-REQ fails due to AES encryption not supported, then there’s a good chance the DC is infected

Authors: 
===================================
Aorato's Research team
Tal Be'ery 
Contact : talbe at microsoft dot com
https://twitter.com/TalBeerySec/

prerequisites
===================================
Python 2.7 needs to be installed


usage:
===================================
powershell ./AoratoSkeletonScan.ps1

