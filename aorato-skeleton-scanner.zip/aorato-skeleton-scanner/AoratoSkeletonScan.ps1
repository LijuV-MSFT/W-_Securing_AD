<#----------------------------------------------------------------------------------------------------
Release Notes:

Aorato Skeleton Key Malware Remote DC Scanner
Version 1:
    Author: Tal Be'ery, Aorato Research team, Microsoft
    https://twitter.com/TalBeerySec/
----------------------------------------------------------------------------------------------------#>


$domain = [System.DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain()
$domain_name = $domain.Name
$domain_DFL = $domain.DomainMode

if ($domain_DFL.value__ -lt 3)
{
	$output = "Domain Functional Level (DFL) must be at least 2008 to test, but the DFL of domain " + $domain_name + " is " + $domain_DFL
	$output = $output -replace "`t|`n|`r",""
	write-output $output
	exit
}
 

$output = "Domain Functional Level (DFL) must be at least 2008 to test, current DFL of domain " + $domain_name + " is " + $domain_DFL + " so the check is valid"
$output = $output -replace "`t|`n|`r",""
write-output $output

$searcher = [ADSISearcher]"(&(objectClass=Computer)(msds-supportedencryptiontypes>=8))" # AES supporting account
$user = $searcher.FindOne()
if($user-eq $Null) 
{
    write-output "There is no AES supporting account current domain"
    exit
}  

$user_name = $user.properties["name"]

$output = "" + $user_name + " account supports AES and will be used for the test"
$output = $output -replace "`t|`n|`r",""
write-output $output

./Get-DomainController.ps1
$DCs = Get-DomainController
$DC_counter = 0
 foreach ($DC in $DCs) {
   $result = &python AoratoTestAes.py -u $user_name@$domain_name -d $DC 2> $Null
   
   if ($result -like "This encryption type is not supported*" )
   {
		$output = $DC + " DC is supposed to support AES but is not. It may be infected with the Skeleton Key malware" 
		$output = $output -replace "`t|`n|`r",""
		write-output $output
		exit
   }

   if ($result -like "This encryption type is supported*" )
   {		 
		$output = $DC + " DC supports AES as it should."  
		$output = $output -replace "`t|`n|`r",""
		$DC_counter = $DC_counter + 1
		write-output $output		
   }
   else
   {
   #some error occured. output the python reported error
		write-output $result
   }
 }
 

$output = "checked " + $DC_counter + " DCs out of " + $DCs.Count + " in domain " + $domain_name + ". None of the checked DCs were found infected"
$output = $output -replace "`t|`n|`r",""
write-output $output

